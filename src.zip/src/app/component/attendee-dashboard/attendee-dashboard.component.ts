import { Component } from '@angular/core';

@Component({
  selector: 'app-attendee-dashboard',
  templateUrl: './attendee-dashboard.component.html',
  styleUrls: ['./attendee-dashboard.component.css']
})
export class AttendeeDashboardComponent {

}
